package data_testcasespackage;

import org.testng.annotations.Test;

import data_page_package.Data_BaseClass;
import data_page_package.Data_LoginPage;

public class Data_Tc1 extends Data_BaseClass
{
	@Test(dataProvider = "cognizant")
	public void verifyvalidlogin(String uname, String pwd)
	{	
		Data_LoginPage login = new Data_LoginPage(driver);
		/*login.typeusername("keerthivasan-2.j-2@cognizant.com");
		login.typepassword("May-2017");
		login.submitbutton();*/
		login.longinfull(uname, pwd);
	}

}
