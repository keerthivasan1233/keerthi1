package data_page_package;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Data_LoginPage 
{
	public WebDriver driver; 
	 By Username =By.id("username");
	 By Password = By.id("password");
	 By Submit = By.xpath("//*[@id=\"bglogodiv\"]/div[7]/div/span");
	 
	public Data_LoginPage(WebDriver driver) 
	{
		this.driver = driver;
	}
	@Test(dataProvider = "cognizant")
	public void longinfull(String uname, String pwd)
	{
		driver.findElement(Username).sendKeys(uname);
		driver.findElement(Password).sendKeys(pwd);
		driver.findElement(Submit).click();
	} 
		
	 public void typeusername(String uname)
	 {
		 driver.findElement(Username).sendKeys(uname);
		 
	 }
	 public void typepassword(String pwd)
	 {
		 driver.findElement(Password).sendKeys(pwd);
	 }
	 public void submitbutton()
	 {
		 driver.findElement(Submit).click();
	 }
	 
	 @DataProvider(name = "cognizant")
	 public Object[][] passdata()
	 {
		 Object[][] data = new Object[3][2];
		 
		 data[0][0] = "keerthi";
		 data[0][1] = "keerthipass";
		 
		 data[1][0] = "keerthivasan-2.j-2@cognizant.com";
		 data[1][1] = "May-2017";
		 
		 data[2][0] = "username";
		 data[2][1] = "password";
		 
		 return data;
	 }
}
