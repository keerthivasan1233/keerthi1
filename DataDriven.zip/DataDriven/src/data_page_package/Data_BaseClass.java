package data_page_package;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class Data_BaseClass
{
public WebDriver driver;
	
    @BeforeClass
	public void launchbrowser()
	{
		System.setProperty("webdriver.chrome.driver","C:\\keerthivasan\\Selenium\\Driver\\chromedriver.exe");
	    driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://mail.cognizant.com");
	}
    
    @AfterClass
    public void closebrowser()
    {
    	driver.quit();
    }
}
